#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTOPORT 60000
#define BUFFER_SIZE 80

#endif /* PROTOCOL_H_ */